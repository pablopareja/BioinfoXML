/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.era7.lib.bioinfoxml.wip;

import com.era7.lib.era7xmlapi.model.XMLElement;
import com.era7.lib.era7xmlapi.model.XMLElementException;
import org.jdom.Element;

/**
 *
 * @author ppareja
 */
public class WipPosition extends XMLElement{

    public static final String TAG_NAME = "wip_position";

    public static final String WORD_TEXT_TAG_NAME = "word_text";
    public static final String WORD_TEXT_PATTERN_TAG_NAME = "word_text_pattern";

    public static final String WORD_LENGTH_TAG_NAME = "word_length";
    public static final String PATTERN_POSITION_TAG_NAME = "pattern_position";    
    public static final String TEXT_POSTIION_TAG_NAME = "text_position";

    public WipPosition() {
        super(new Element(TAG_NAME));
    }

    public WipPosition(Element elem) throws XMLElementException {
        super(elem);
        if (!elem.getName().equals(TAG_NAME)) {
            throw new XMLElementException(XMLElementException.WRONG_TAG_NAME, new XMLElement(elem));
        }
    }

    public WipPosition(String value) throws Exception {
        super(value);
        if (!root.getName().equals(TAG_NAME)) {
            throw new XMLElementException(XMLElementException.WRONG_TAG_NAME, new XMLElement(value));
        }
    }

    //----------------GETTERS---------------------
    public String getWordText( ){  return getNodeText(WORD_TEXT_TAG_NAME);}
    public String getWordTextPattern( ){  return getNodeText(WORD_TEXT_PATTERN_TAG_NAME);}
    public int getWordLength( ){  return Integer.parseInt(getNodeText(WORD_LENGTH_TAG_NAME));}
    public int getPatternPosition(){    return Integer.parseInt(getNodeText(PATTERN_POSITION_TAG_NAME));}
    public int getTextPosition(){   return Integer.parseInt(getNodeText(TEXT_POSTIION_TAG_NAME));}


    //----------------SETTERS---------------------
    public void setWordText(String value){  setNodeText(WORD_TEXT_TAG_NAME, value);}
    public void setWordTextPattern(String value){   setNodeText(WORD_TEXT_PATTERN_TAG_NAME, value);}
    public void setWordLength(int value){   setNodeText(WORD_LENGTH_TAG_NAME, String.valueOf(value));}
    public void setPatternPosition(int value){  setNodeText(PATTERN_POSITION_TAG_NAME, String.valueOf(value));}
    public void setTextPosition(int value){ setNodeText(TEXT_POSTIION_TAG_NAME, String.valueOf(value));}

}
